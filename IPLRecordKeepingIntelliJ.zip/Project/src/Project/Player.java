package Project;

public abstract class Player {
    protected int pid;
    protected String name;
    protected int age;
    protected int matches;
    protected int stumps;
    protected int tno;
    private static int noOfPlayers = 0;
    public Player(){
        pid = ++noOfPlayers;
        name = "";
        age = 0;
        matches = 0;
        stumps = -1;
        tno = -1;
    }
    public Player(String n, int a , int m, int s){
        pid = ++noOfPlayers;
        name = n;
        age = a;
        matches = m;
        stumps = s;
        tno = -1;
    }
    public static int getNoOfPlayers(){
        return noOfPlayers;
    }
    public void assignToTeam(int tno){
        this.tno = tno;
    }
    public void incMatches(){
        matches++;
    }
    public void incMatches(int i){
        matches += i;
    }
    public void incStumps(){
        stumps++;
    }
    public void incStumps(int i){
        stumps += i;
    }
    public int getId(){
        return pid;
    }
    public String getName(){
        return name;
    }
    public int getTeamNo(){
        return tno;
    }
    public int getMatches(){
        return matches;
    }
    public int getStumps(){
        return stumps;
    }
    public String displayPlayer(){
        String s = "";
        s = s + name + "  id : "+pid+"\n";
        s = s + "Age    Matches         Team\n";
        s = s + "  " + age + "    " + matches;
        return s;
    }

    @Override
    public String toString(){
        return name;
    }
}

interface Batting {
    public double getAverage();
    public void incRuns(int r);
    public void incInning();
    public void incInnings(int i);
    public void incFifty();
    public void incFifties(int f);
}

class Batsman extends Player implements Batting{
    protected int innings;
    protected int runs;
    protected double strikeRate;
    protected int fifty;
    public Batsman(){
        innings = 0;
        runs = 0;
        strikeRate = 0;
        fifty = 0;
    }
    public Batsman(String n, int a, int m, int s, int i, int r, double sr, int f){
        super(n, a, m, s);
        innings = i;
        runs = r;
        strikeRate = sr;
        fifty = f;
    }

    @Override
    public double getAverage() {
        return runs*1.0/innings;
    }
    public void incInning() {
        innings++;
    }
    public void incInnings(int i) {
        innings += i;
    }
    public void incRuns(int r) {
        runs += r;
    }
    public void incFifty() {
        fifty++;
    }
    public void incFifties(int f) {
        fifty += f;
    }

}

interface Bowling {
    public double getRunRate();
    public void incRunsGiven(int r);
    public void incBall();
    public void incBalls(int b);
    public void incWicket();
    public void incWickets(int w);
    public void incOver();
    public void incOvers(double o);
}

class Bowler extends Player implements Bowling{
    protected double overs;
    protected int runsGiven;
    protected int wickets;
    public Bowler(){
        overs = 0;
        runsGiven = 0;
        wickets = 0;
    }
    public Bowler(String n,int a,int m, int s, double o, int r, int w){
        super(n, a, m, s);
        overs = o;
        runsGiven = r;
        wickets = w;
    }

    @Override
    public double getRunRate() {
        double x = (overs-(int)overs)*10/6;
        return runsGiven/(x+(int)overs);
    }
    public void incBall(){
        if(overs-(int)overs<0.5)
            overs += 0.1;
        else
            overs = (int)++overs;
    }
    public void incBalls(int b){
        for(int i = 0; i < b; i++)
            incBall();
    }
    public void incOver(){
        overs++;
    }
    public void incOvers(double o){
        overs += (int)o;
        incBalls((int)((o-(int)o)*10));
    }
    public void incRunsGiven(int r){
        runsGiven += r;
    }
    public void incWicket(){
        wickets++;
    }
    public void incWickets(int w){
        wickets += w;
    }
}

class AllRounder extends Player implements Batting, Bowling{
    private int innings;
    private int runs;
    private double strikeRate;
    private int fifty;
    private double overs;
    private int runsGiven;
    private int wickets;
    public AllRounder(){
        innings = 0;
        runs = 0;
        strikeRate = 0;
        fifty = 0;
        overs = 0;
        runsGiven = 0;
        wickets = 0;
    }
    public AllRounder(String n, int a, int m, int s, int i, int r, double sr, int f, double o, int rg, int w){
        super(n, a, m, s);
        innings = i;
        runs = r;
        strikeRate = sr;
        fifty = f;
        overs = o;
        runsGiven = rg;
        wickets = w;
    }

    @Override
    public double getAverage() {
        return runs*1.0/innings;
    }
    public void incInning() {
        innings++;
    }
    public void incInnings(int i) {
        innings += i;
    }
    public void incRuns(int r) {
        runs += r;
    }
    public void incFifty() {
        fifty++;
    }
    public void incFifties(int f) {
        fifty += f;
    }
    public double getRunRate() {
        double x = (overs-(int)overs)*10/6;
        return runsGiven/(x+(int)overs);
    }
    public void incBall(){
        if(overs-(int)overs<0.5)
            overs += 0.1;
        else
            overs = (int)++overs;
    }
    public void incBalls(int b){
        for(int i = 0; i < b; i++)
            incBall();
    }
    public void incOver(){
        overs++;
    }
    public void incOvers(double o){
        overs += (int)o;
        incBalls((int)((o-(int)o)*10));
    }
    public void incRunsGiven(int r){
        runsGiven += r;
    }
    public void incWicket(){
        wickets++;
    }
    public void incWickets(int w){
        wickets += w;
    }
}

class PlayerRec{
    private int id;
    private String name;
    private int teamId;
    private int played;
    private int batted;
    private int stumps;
    private int runsScored;
    private int fifty;
    private double oversFaced;
    private int runsGiven;
    private int wickets;
    private double oversBowled;
    public void reset(){
        played = 0;
        stumps = 0;
        batted = 0;
        runsScored = 0;
        fifty = 0;
        oversFaced = 0;
        runsGiven = 0;
        wickets = 0;
        oversBowled = 0;
    }
    public PlayerRec(Player p){
        id = p.getId();
        name = p.getName();
        teamId = p.getTeamNo();
        reset();
    }
    public int getId(){
        return id;
    }
    public int getTeamId(){
        return teamId;
    }
    public int getPlayed(){
        return played;
    }
    public void setPlayed(int p){
        played = p;
    }
    public void incPlayed(){
        played++;
    }
    public void incPlayed(int i){
        played += i;
    }
    public int getBatted(){
        return batted;
    }
    public void setBatted(int b){
        batted = b;
    }
    public void incBatted(){
        batted++;
    }
    public void incBatted(int i){
        batted += i;
    }
    public int getStumps(){
        return stumps;
    }
    public void setStumps(int s){
        stumps = s;
    }
    public void incStumps(){
        stumps++;
    }
    public void incStumps(int i){
        stumps += i;
    }
    public int getRS(){
        return runsScored;
    }
    public void setRunsScored(int rs){
        runsScored = rs;
    }
    public void incRunsScored(int i){
        runsScored += i;
    }
    public int getFifty(){
        return fifty;
    }
    public void setFifty(int f){
        fifty = f;
    }
    public void incFifty(){
        fifty++;
    }
    public void incFifty(int i){
        fifty += i;
    }
    public double getOF(){
        return oversFaced;
    }
    public void incBallFaced(){
        if(oversFaced - (int)oversFaced < 0.5)
            oversFaced += 0.1;
        else
            oversFaced = (int)++oversFaced;
    }
    public void incBallsFaced(int b){
        for(int i = 0; i < b; i++)
            incBallFaced();
    }
    public void incOversFaced(double o){
        oversFaced += (int)o;
        incBallsFaced((int)((o - (int)o) * 10));
    }
    public int getRG(){
        return runsGiven;
    }
    public void setRunsGiven(int rg){
        runsGiven = rg;
    }
    public void incRunsGiven(int i){
        runsGiven += i;
    }
    public int getWickets(){
        return wickets;
    }
    public void setWickets(int w){
        wickets = w;
    }
    public void incWickets(){
        wickets++;
    }
    public void incWickets(int i){
        wickets += i;
    }
    public double getOB(){
        return oversBowled;
    }
    public void incBallBowled(){
        if(oversBowled - (int)oversBowled < 0.5)
            oversBowled += 0.1;
        else
            oversBowled = (int)++oversBowled;
    }
    public void incBallsBowled(int b){
        for(int i = 0; i < b; i++)
            incBallBowled();
    }
    public void incOversBowled(double o){
        oversBowled += (int)o;
        incBallsBowled((int)((o - (int)o) * 10));
    }
}

