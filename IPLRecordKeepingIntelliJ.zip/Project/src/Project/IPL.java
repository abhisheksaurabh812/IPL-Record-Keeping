package Project;

import javax.swing.*;
import java.util.ArrayList;

public class IPL {
    private String heading;
    private ArrayList<Bowler> bowlers;
    private ArrayList<Batsman> batsman;
    private ArrayList<AllRounder> allRounders;
    private ArrayList<TeamRec> iplTeamRecs;
    private ArrayList<PlayerRec> iplPlayerRecs;
    private ArrayList<Team> teams;
    private static IPL instance = new IPL();
    private IPL(){
        heading = "";
        bowlers = null;
        batsman = null;
        allRounders = null;
        teams = null;
        iplPlayerRecs = null;
        iplTeamRecs = null;
    }
    private void setup(ArrayList<Bowler> bo, ArrayList<Batsman> ba, ArrayList<AllRounder> al, ArrayList<Team> te){
        bowlers = bo;
        batsman = ba;
        allRounders = al;
        teams = te;
        iplPlayerRecs = new ArrayList<PlayerRec>(ba.size() + bo.size() + al.size());
        iplTeamRecs = new ArrayList<TeamRec>(te.size());
        int i;
        for(i = 0; i < ba.size(); i++)
            iplPlayerRecs.add(new PlayerRec(batsman.get(i)));
        for(; i < ba.size() + bo.size(); i++)
            iplPlayerRecs.add(new PlayerRec(bowlers.get(i - ba.size())));
        for(; i < iplPlayerRecs.size(); i++)
            iplPlayerRecs.add(new PlayerRec(batsman.get(i - ba.size() - bo.size())));
        for(i = 0; i < te.size(); i++)
            iplTeamRecs.add(new TeamRec(te.get(i)));
    }
    class Tournament{
        private String year;
        private ArrayList<Match> matchList;
        private ArrayList<TeamRec> tourneyTeamRecs;
        private ArrayList<PlayerRec> tourneyPlayerRecs;
        private int cmno;
        public Tournament(ArrayList<String> ml) {
            year = "";
            matchList = new ArrayList<Match>(10);
            for(int i = 0; i < ml.size(); i++)
                matchList.add(new Match(ml.get(i)));
            tourneyTeamRecs = (ArrayList<TeamRec>) iplTeamRecs.clone();
            tourneyPlayerRecs = (ArrayList<PlayerRec>) iplPlayerRecs.clone();
            cmno = 0;
            for (int i = 0; i < tourneyPlayerRecs.size(); i++)
                tourneyPlayerRecs.get(i).reset();
            for (int i = 0; i < tourneyTeamRecs.size(); i++)
                tourneyTeamRecs.get(i).reset();
        }
        public ArrayList<Match> getMatchList(){
            return matchList;
        }
        public Match getMatch(){
            return matchList.get(cmno);
        }
        public int getPlayerRecIndex(int id){
            for(int i = 0; i < tourneyPlayerRecs.size(); i++) {
                if (tourneyPlayerRecs.get(i).getId() == id) {
                    return i;
                }
            }
            return -1;
        }
        public int getTeamRecIndex(int id){
            for(int i = 0; i < tourneyTeamRecs.size(); i++) {
                if (tourneyTeamRecs.get(i).getId() == id) {
                    return i;
                }
            }
            return -1;
        }
        public void flush(Match m){

        }
        class Match{
            private String title;
            private Team team1;
            private Team team2;
            private ArrayList<PlayerRec> matchPlayerRecs;
            private MatchState state;
            private MatchResult mrTeam1;
            private MatchResult mrTeam2;
            private boolean swapped;
            public Match(String t){
                title = t;
                int k = t.indexOf(" vs ");
                team1 = getTeam(t.substring(0,k));
                team2 = getTeam(t.substring(k+4));
                state = new MatchState();
                matchPlayerRecs = new ArrayList<PlayerRec>(team1.getSize() + team2.getSize());
                int i;
                for(i = 0; i < team1.getSize(); i++)
                    matchPlayerRecs.add(new PlayerRec(team1.getMember(i)));
                for(; i < (team1.getSize() + team2.getSize()); i++)
                    matchPlayerRecs.add(new PlayerRec(team2.getMember(i - team1.getSize())));
                mrTeam1 = new MatchResult();
                mrTeam2 = new MatchResult();
                swapped = false;
            }
            public void proceed(int c, int r, int w, int ro){
                int cb1 = getRecIndex(getState().getBat1());
                int cb2 = getRecIndex(getState().getBat2());
                int cb = getRecIndex(getState().getBow());
                int ck = getRecIndex(getState().getKeep());
                switch(c){
                    case 1: state.incBall();
                            state.incRuns(r);
                            if(r%2 != 0)
                                state.swapBat();
                            matchPlayerRecs.get(cb1).incBallFaced();
                            matchPlayerRecs.get(cb1).incRunsScored(r);
                            matchPlayerRecs.get(cb).incRunsGiven(r);
                            matchPlayerRecs.get(cb).incBallBowled();
                            break;
                    case 2: break;
                }
                if(state.getOvers() == 20) {
                    if (state.getFlag() == 1) {
                        state.incFlag();
                        swapTeams();
                    }
                }
            }
            public String getTitle(){
                return title;
            }
            public Team getTeam1(){
                return team1;
            }
            public Team getTeam2(){
                return team2;
            }
            public boolean isSwapped(){
                return swapped;
            }
            public MatchState getState(){
                return state.getState();
            }
            public void swapTeams(){
                Team t = team1;
                team1 = team2;
                team2 = t;
                swapped = !swapped;
            }
            public int getRecIndex(int id){
                for(int i = 0; i < matchPlayerRecs.size(); i++){
                    if(matchPlayerRecs.get(i).getId() == id){
                        return i;
                    }
                }
                return -1;
            }
            public PlayerRec getRecord(int id){
                for(int i = 0; i < matchPlayerRecs.size(); i++){
                    if(matchPlayerRecs.get(i).getId() == id){
                        return matchPlayerRecs.get(i);
                    }
                }
                return null;
            }
        }
    }
    public void assignTeams(){
        for(int i = 0; i < batsman.size(); i++){
            batsman.get(i).assignToTeam(i % teams.size());
            teams.get(i % teams.size()).addPlayer(batsman.get(i));
        }
        for(int i = 0; i < bowlers.size(); i++){
            bowlers.get(i).assignToTeam(i % teams.size());
            teams.get(i % teams.size()).addPlayer(bowlers.get(i));
        }
        for(int i = 0; i < allRounders.size(); i++){
            allRounders.get(i).assignToTeam(i % teams.size());
            teams.get(i % teams.size()).addPlayer(allRounders.get(i));
        }
    }
    public String displayTeams(){
        String s = "";
        for(int i = 0; i < teams.size(); i++){
            s = s + teams.get(i).getName() + "\n";
        }
        return s;
    }
    public String getTeam(int id){
        for(int i = 0; i < teams.size(); i++){
            if(teams.get(i).getId() == id){
                return teams.get(i).getName();
            }
        }
        return "Not assigned";
    }
    public Team getTeam(String n){
        for(int i = 0; i < teams.size(); i++){
            if(teams.get(i).getName().compareTo(n) == 0){
                return teams.get(i);
            }
        }
        return null;
    }
    public String searchPlayer(int id){
        String s = "";
        int i;
        for(i = 0; i < batsman.size(); i++){
            if(batsman.get(i).getId() == id){
                s = batsman.get(i).displayPlayer();
                s = s +"        "+ getTeam(batsman.get(i).getTeamNo());
            }
        }
        for(i = 0; i < bowlers.size(); i++){
            if(bowlers.get(i).getId() == id){
                s = bowlers.get(i).displayPlayer();
                s = s +"        "+ getTeam(bowlers.get(i).getTeamNo());
            }
        }
        for(i = 0; i < allRounders.size(); i++){
            if(allRounders.get(i).getId() == id){
                s = allRounders.get(i).displayPlayer();
                s = s +"        "+ getTeam(allRounders.get(i).getTeamNo());
            }
        }
        return s;
    }
    public String getPlayerName(int id){
        String s = "";
        int i;
        for(i = 0; i < batsman.size(); i++){
            if(batsman.get(i).getId() == id){
                s = batsman.get(i).getName();
            }
        }
        for(i = 0; i < bowlers.size(); i++){
            if(bowlers.get(i).getId() == id){
                s = bowlers.get(i).getName();
            }
        }
        for(i = 0; i < allRounders.size(); i++){
            if(allRounders.get(i).getId() == id){
                s = allRounders.get(i).getName();
            }
        }
        return s;
    }
    public String searchPlayer(String n){
        String s = "";
        int i;
        for(i = 0; i < batsman.size(); i++){
            if(batsman.get(i).getName().compareTo(n) == 0){
                s = batsman.get(i).displayPlayer();
                s = s +"        "+ getTeam(batsman.get(i).getTeamNo());
            }
        }
        for(i = 0; i < bowlers.size(); i++){
            if(bowlers.get(i).getName().compareTo(n) == 0){
                s = bowlers.get(i).displayPlayer();
                s = s +"        "+ getTeam(bowlers.get(i).getTeamNo());
            }
        }
        for(i = 0; i < allRounders.size(); i++){
            if(allRounders.get(i).getName().compareTo(n) == 0){
                s = allRounders.get(i).displayPlayer();
                s = s +"        "+ getTeam(allRounders.get(i).getTeamNo());
            }
        }
        return s;
    }
    public static IPL getIpl(ArrayList<Bowler> bo, ArrayList<Batsman> ba, ArrayList<AllRounder> al, ArrayList<Team> te)
    {
        instance.setup(bo, ba, al, te);
        return instance;
    }
}
