package Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;

public class IPLRecordKeeping{
    private JButton displayTeamsButton;
    private JPanel Start;
    private JButton searchPlayerButton;
    private JButton manageTeamsButton;
    private JButton managePlayersButton;
    private JButton enterTournamentButton;
    private JTextField textField2;
    private JTextField textField1;
    private JButton searchButton;
    private JTextArea textArea1;
    private JTextArea textArea2;
    private JPanel Welcome;
    private JPanel DisplayTeams;
    private JPanel SearchPlayer;
    private JButton backButton;
    private JButton backButton1;
    private JPanel tournamentPanel;
    private JButton displayMatchListButton;
    private JButton displayStatsButton;
    private JButton enterCurrentMatchButton;
    private JButton displayPointsTableButton;
    private JButton backButton2;
    private JPanel displayMatchListPanel;
    private JTextArea textArea3;
    private JButton backButton3;
    private JPanel matchPanel1;
    private JPanel matchPanel2;
    private JPanel matchPanel3;
    private JButton startMatchButton;
    private JLabel matchHead;
    private JRadioButton radioButton1;
    private JRadioButton radioButton2;
    private JButton backButton4;
    private JComboBox comboBox1;
    private JComboBox comboBox2;
    private JComboBox comboBox3;
    private JComboBox comboBox4;
    private JButton startRecordKeepingButton;
    private JButton backButton5;
    private JPanel recordKeepingPanel;
    private JButton displayStatsButton1;
    private JButton changeKeeperButton;
    private JButton displayMatchStateButton;
    private JButton startRecordKeepingButton1;
    private JButton restartMatchButton;
    private JButton backToTournamentMenuButton;
    private JRadioButton radioButton3;
    private JRadioButton radioButton4;
    private JRadioButton radioButton5;
    private JLabel scoreLabel;
    private JLabel projectedScoreLabel;
    private JRadioButton radioButton6;
    private JRadioButton radioButton7;
    private JRadioButton radioButton8;
    private JButton matchMenuButton;
    private JComboBox comboBox5;
    private JRadioButton radioButton9;
    private JRadioButton radioButton10;
    private JRadioButton radioButton11;
    private JLabel runsLabel;
    private JLabel wicketsLabel;
    private JButton nextButton;
    private JLabel runOutLabel;
    private JRadioButton radioButton12;
    private JRadioButton radioButton13;
    private JLabel currentPlayersLabel;
    private JButton changeBowlerButton;
    private JPanel selectPlayerPanel;
    private JComboBox comboBox6;
    private JButton selectButton;
    private JButton backToMatchMenuButton;
    private JLabel choosePlayerLabel;
    private JPanel displayStatsByOvers;
    private JTextArea textArea4;
    private JButton showRecordOfOversButton;
    private JButton backButton6;

    public IPLRecordKeeping() {
        int runsThisOver = 0;
        ArrayList<Batsman> ba = new ArrayList<Batsman>(20);
        ArrayList<Bowler> bo = new ArrayList<Bowler>(20);
        ArrayList<AllRounder> al = new ArrayList<AllRounder>(20);
        ArrayList<Team> te = new ArrayList<Team>(20);
        ArrayList<String> ml = new ArrayList<String>(10);
        File file = new File("C:\\Users\\abhis\\Desktop\\cleanup\\sem5\\Java\\Project\\src\\Project\\Data\\BatsmenData.txt");
        Scanner sc = null;
        try{
            sc = new Scanner(file);
        }catch (FileNotFoundException e1){
            e1.printStackTrace();
        }
        String n;
        int a, m, s, in, r, f, rg, w, l, d;
        double sr, o;
        while(sc.hasNext()){
            n = sc.nextLine();
            a = sc.nextInt();
            m = sc.nextInt();
            s = sc.nextInt();
            in = sc.nextInt();
            r = sc.nextInt();
            sr = sc.nextDouble();
            f = Integer.parseInt(sc.nextLine().trim());
            ba.add(new Batsman(n, a, m, s, in, r, sr, f));
        }
        file = new File("C:\\Users\\abhis\\Desktop\\cleanup\\sem5\\Java\\Project\\src\\Project\\Data\\BowlersData.txt");
        try{
            sc = new Scanner(file);
        }catch (FileNotFoundException e1){
            e1.printStackTrace();
        }
        while(sc.hasNext()){
            n = sc.nextLine();
            a = sc.nextInt();
            m = sc.nextInt();
            s = sc.nextInt();
            o = sc.nextDouble();
            rg = sc.nextInt();
            w = Integer.parseInt(sc.nextLine().trim());
            bo.add(new Bowler(n, a, m, s, o, rg, w));
        }
        file = new File("C:\\Users\\abhis\\Desktop\\cleanup\\sem5\\Java\\Project\\src\\Project\\Data\\AllRoundersData.txt");
        try{
            sc = new Scanner(file);
        }catch (FileNotFoundException e1){
            e1.printStackTrace();
        }
        while(sc.hasNext()){
            n = sc.nextLine();
            a = sc.nextInt();
            m = sc.nextInt();
            s = sc.nextInt();
            in = sc.nextInt();
            r = sc.nextInt();
            sr = sc.nextDouble();
            f = sc.nextInt();
            o = sc.nextDouble();
            rg = sc.nextInt();
            w = Integer.parseInt(sc.nextLine().trim());
            al.add(new AllRounder(n, a, m, s, in, r, sr, f, o, rg, w));
        }
        file = new File("C:\\Users\\abhis\\Desktop\\cleanup\\sem5\\Java\\Project\\src\\Project\\Data\\TeamsData.txt");
        try{
            sc = new Scanner(file);
        }catch (FileNotFoundException e1){
            e1.printStackTrace();
        }
        while(sc.hasNext()){
            n = sc.nextLine();
            m = sc.nextInt();
            w = sc.nextInt();
            l = sc.nextInt();
            d = Integer.parseInt(sc.nextLine().trim());
            te.add(new Team(n, m, w, l, d));
        }
        IPL ipl = IPL.getIpl(bo, ba, al, te);
        file = new File("C:\\Users\\abhis\\Desktop\\cleanup\\sem5\\Java\\Project\\src\\Project\\Data\\MatchList.txt");
        try{
            sc = new Scanner(file);
        }catch (FileNotFoundException e1){
            e1.printStackTrace();
        }
        while(sc.hasNext()){
            ml.add(sc.nextLine().trim());
        }
        ipl.assignTeams();
        IPL.Tournament tour = ipl.new Tournament(ml);
        radioButton3.setText("Runs taken");
        radioButton4.setText("Four");
        radioButton5.setText("Six");
        radioButton6.setText("Wicket");
        radioButton7.setText("Wide");
        radioButton8.setText("No ball");
        radioButton9.setText("Bowled/Caught/LBW");
        radioButton10.setText("Stump");
        radioButton11.setText("Run out");
        for(int i = 0; i < 6; i++){
            comboBox5.addItem(i);
        }
        displayTeamsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Welcome.setVisible(false);
                textArea2.append(ipl.displayTeams());
                DisplayTeams.setVisible(true);
            }
        });
        searchPlayerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Welcome.setVisible(false);
                textArea1.setVisible(false);
                SearchPlayer.setVisible(true);
            }
        });
        backButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SearchPlayer.setVisible(false);
                Welcome.setVisible(true);
            }
        });
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea2.setText("");
                DisplayTeams.setVisible(false);
                Welcome.setVisible(true);
            }
        });
        enterTournamentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Welcome.setVisible(false);
                tournamentPanel.setVisible(true);
            }
        });
        backButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tournamentPanel.setVisible(false);
                Welcome.setVisible(true);
            }
        });
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = 0;
                if(textField1.getText().compareTo("") != 0)
                    id = Integer.parseInt(textField1.getText());
                String n = textField2.getText();
                textArea1.setText("");
                textField1.setText("");
                textField2.setText("");
                if(id != 0)
                    textArea1.append(ipl.searchPlayer(id));
                else
                    textArea1.append(ipl.searchPlayer(n));
                textArea1.setVisible(true);
            }
        });
        displayMatchListButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tournamentPanel.setVisible(false);
                displayMatchListPanel.setVisible(true);
                for(int i = 0; i < tour.getMatchList().size(); i ++)
                    textArea3.append(tour.getMatchList().get(i).getTitle() + "\n");
            }
        });
        backButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea3.setText("");
                displayMatchListPanel.setVisible(false);
                tournamentPanel.setVisible(true);
            }
        });
        enterCurrentMatchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                IPL.Tournament.Match cm = tour.getMatch();
                tournamentPanel.setVisible(false);
                switch(cm.getState().getFlag()){
                    case 0: matchHead.setText(cm.getTitle());
                            radioButton1.setText(cm.getTeam1().getName());
                            radioButton2.setText(cm.getTeam2().getName());
                            matchPanel1.setVisible(true);
                            break;
                    case 1: setupRecordKeepingPanel(cm);
                            recordKeepingPanel.setVisible(true);
                            break;
                }
            }
        });
        backButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                matchPanel1.setVisible(false);
                tournamentPanel.setVisible(true);
            }
        });
        startMatchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                IPL.Tournament.Match cm = tour.getMatch();
                matchPanel1.setVisible(false);
                for(int i = 0; i < cm.getTeam1().getSize(); i++)
                    comboBox1.addItem(cm.getTeam1().getMember(i));
                for(int i = 0; i < cm.getTeam1().getSize(); i++)
                    comboBox2.addItem(cm.getTeam1().getMember(i));
                for(int i = 0; i < cm.getTeam2().getSize(); i++)
                    comboBox3.addItem(cm.getTeam2().getMember(i));
                for(int i = 0; i < cm.getTeam2().getSize(); i++)
                    comboBox4.addItem(cm.getTeam2().getMember(i));
                matchPanel3.setVisible(true);
            }
        });
        startRecordKeepingButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                IPL.Tournament.Match cm = tour.getMatch();
                if(radioButton2.isSelected()){
                    radioButton2.setSelected(false);
                    cm.swapTeams();
                }
                int cb1 = ((Player)comboBox1.getSelectedItem()).getId();
                int cb2 = ((Player)comboBox2.getSelectedItem()).getId();
                int cb = ((Player)comboBox3.getSelectedItem()).getId();
                int ck = ((Player)comboBox4.getSelectedItem()).getId();
                cm.getState().init(cb1, cb2, cb, ck);
                matchPanel3.setVisible(false);
                setupRecordKeepingPanel(cm);
                recordKeepingPanel.setVisible(true);
            }
        });
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int c, r, w, ro;
                if(radioButton3.isSelected()){
                    c = 1;
                    r = (int)comboBox5.getSelectedItem();
                    w = 0;
                    ro = 0;
                }
                else if(radioButton4.isSelected()){
                    c = 1;
                    r = 4;
                    w = 0;
                    ro = 0;
                }
                else if(radioButton5.isSelected()){
                    c = 1;
                    r = 6;
                    w = 0;
                    ro = 0;
                }
                else if(radioButton6.isSelected()){
                    c = 2;
                    r = (int)comboBox5.getSelectedItem();
                    if(radioButton9.isSelected()) {
                        w = 1;
                        ro = 0;
                    }
                    else if(radioButton10.isSelected()) {
                        w = 2;
                        ro = 0;
                    }
                    else{
                        w = 3;
                        ro = (radioButton12.isSelected()) ? 1 : 2;
                    }
                }
                else if(radioButton7.isSelected()){
                    c = 3;
                    r = (int)comboBox5.getSelectedItem();
                    w = 0;
                    ro = 0;
                }
                else{
                    c = 4;
                    r = (int)comboBox5.getSelectedItem();
                    w = 0;
                    ro = 0;
                }
                tour.getMatch().proceed(c, r, w, ro);
                IPL.Tournament.Match cm = tour.getMatch();
                textArea4.append(r+"  ");
                if(cm.getState().getOvers() - (int)(cm.getState().getOvers()) == 0){
                    textArea4.append("  Over "+(int)(cm.getState().getOvers())+" by "+ipl.getPlayerName(cm.getState().getBow())+"    faced by "+ipl.getPlayerName(cm.getState().getBat1())+" and "+ipl.getPlayerName(cm.getState().getBat2())+"\n");
                }
                setupRecordKeepingPanel(tour.getMatch());
            }
        });
        matchMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                recordKeepingPanel.setVisible(false);
                matchPanel2.setVisible(true);
            }
        });
        startRecordKeepingButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setupRecordKeepingPanel(tour.getMatch());
                matchPanel2.setVisible(false);
                recordKeepingPanel.setVisible(true);
            }
        });
        backToTournamentMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                matchPanel2.setVisible(false);
                tournamentPanel.setVisible(true);
            }
        });
        changeBowlerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                matchPanel2.setVisible(false);
                selectPlayerPanel.setVisible(true);
                choosePlayerLabel.setText("Choose Bowler :");
                for(int i = 0; i < tour.getMatch().getTeam2().getSize(); i++)
                    comboBox6.addItem(tour.getMatch().getTeam2().getMember(i));
                selectButton.setText("Select Bowler");
            }
        });
        changeKeeperButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                matchPanel2.setVisible(false);
                selectPlayerPanel.setVisible(true);
                choosePlayerLabel.setText("Choose Keeper :");
                for(int i = 0; i < tour.getMatch().getTeam2().getSize(); i++)
                    comboBox6.addItem(tour.getMatch().getTeam2().getMember(i));
                selectButton.setText("Select Keeper");
            }
        });
        backToMatchMenuButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectPlayerPanel.setVisible(false);
                matchPanel2.setVisible(true);
            }
        });
        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(choosePlayerLabel.getText().compareTo("Choose Bowler :") == 0)
                    tour.getMatch().getState().setCurrBow(((Player)comboBox6.getSelectedItem()).getId());
                else
                    tour.getMatch().getState().setCurrKeep(((Player)comboBox6.getSelectedItem()).getId());
                comboBox6.removeAllItems();
                selectPlayerPanel.setVisible(false);
                matchPanel2.setVisible(true);
            }
        });
        showRecordOfOversButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayStatsByOvers.setVisible(true);
                matchPanel2.setVisible(false);
            }
        });
        backButton6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayStatsByOvers.setVisible(false);
                matchPanel2.setVisible(true);
            }
        });
    }
    public void setupRecordKeepingPanel(IPL.Tournament.Match cm){
        scoreLabel.setText(cm.getTeam1().getName()+" : "+cm.getState().getRuns()+"/"+cm.getState().getWickets()+"  "+String.format("%.1f",cm.getState().getOvers())+" overs");
        String b1 = cm.getTeam1().getPlayer(cm.getState().getBat1()).getName();
        int b1r = cm.getRecord(cm.getTeam1().getPlayer(cm.getState().getBat1()).getId()).getRS();
        String b2 = cm.getTeam1().getPlayer(cm.getState().getBat2()).getName();
        int b2r = cm.getRecord(cm.getTeam1().getPlayer(cm.getState().getBat2()).getId()).getRS();
        String b = cm.getTeam2().getPlayer(cm.getState().getBow()).getName();
        double ob = cm.getRecord(cm.getTeam2().getPlayer(cm.getState().getBow()).getId()).getOB();
        radioButton12.setText(b1);
        radioButton13.setText(b2);
        projectedScoreLabel.setText("Projected Score : "+cm.getState().getProjected());
        currentPlayersLabel.setText(b1+"* "+b1r+"   "+b2+" "+b2r+"     "+b+" "+String.format("%.1f",ob)+" overs");
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("IPLRecordKeeping");
        frame.setContentPane(new IPLRecordKeeping().Start);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
