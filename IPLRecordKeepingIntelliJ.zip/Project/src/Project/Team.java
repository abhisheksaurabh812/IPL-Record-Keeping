package Project;

import java.util.ArrayList;

public class Team {
    private int tid;
    private String name;
    private int matches;
    private int wins;
    private int loss;
    private int draw;
    private Player cap;
    private ArrayList<Player> members;
    private static int noOfTeams = -1;
    public static int getNoOfTeams(){
        return noOfTeams;
    }
    public Team(){
        tid = ++noOfTeams;
        name = "";
        matches = 0;
        wins = 0;
        loss = 0;
        draw = 0;
        cap = null;
        members = new ArrayList<Player>();
    }
    public Team(String n, int m, int w, int l, int d){
        tid = ++noOfTeams;
        name = n;
        matches = m;
        wins = w;
        loss = l;
        draw = d;
        cap = null;
        members = new ArrayList<Player>(15);
    }
    public int getId(){
        return tid;
    }
    public String getName(){
        return name;
    }
    public int getSize(){
        return members.size();
    }
    public Player getMember(int id){
        return members.get(id);
    }
    public void incWins(){
        wins++;
        matches++;
    }
    public void incWins(int i){
        wins += i;
        matches += i;
    }
    public void incLoss(){
        loss++;
        matches++;
    }
    public void incLoss(int i){
        loss += i;
        matches += i;
    }
    public void incDraws(){
        draw++;
        matches++;
    }
    public void incDraws(int i){
        draw += i;
        matches += i;
    }
    public boolean search(int id){
        for(int i = 0; i < members.size(); i++){
            if(members.get(i).getId() == id){
                return true;
            }
        }
        return false;
    }
    public Player getPlayer(int id){
        for(int i = 0; i < members.size(); i++){
            if(members.get(i).getId() == id){
                return members.get(i);
            }
        }
        return null;
    }
    public void addPlayer(Player p){
        members.add(p);
    }
    public void assignCap(Player c) {
        cap = c;
    }
    public void setupMatchRec(){}
}

class TeamRec{
    private int id;
    private String name;
    private int matches;
    private int wins;
    private int loss;
    private int draw;
    public TeamRec(){
        id = 0;
        name = "";
        reset();
    }
    public TeamRec(Team t){
        id = t.getId();
        name = t.getName();
        reset();
    }
    public int getId(){
        return id;
    }
    public void reset(){
        matches = 0;
        wins = 0;
        loss = 0;
        draw = 0;
    }
    public void incMatches(){
        matches++;
    }
    public void incMatches(int i){
        matches += i;
    }
    public void incWins(){
        wins++;
    }
    public void incWins(int i){
        wins += i;
    }
    public void incLoss(){
        loss++;
    }
    public void incLoss(int i){
        loss += i;
    }
    public void incDraw(){
        draw++;
    }
    public void incDraw(int i){
        draw += i;
    }
    public int getPoints(){
        return 2 * wins + draw;
    }
    public static boolean comparePoints(TeamRec tr1, TeamRec tr2){
        return tr1.getPoints() > tr2.getPoints();
    }
};

class MatchState{
    private int sFlag;
    private int runs;
    private int wickets;
    private int currBat1;
    private int currBat2;
    private int currBow;
    private int currKeep;
    private double overs;
    public MatchState(){
        reset();
    }
    public void reset(){
        currBat1 = -1;
        currBat2 = -1;
        currBow = -1;
        currKeep = -1;
        overs = 0;
        runs = 0;
        wickets = 0;
        sFlag = 0;
    }
    public void init(int cb1, int cb2, int cb, int ck){
        currBat1 = cb1;
        currBat2 = cb2;
        currBow = cb;
        currKeep = ck;
        overs = 0;
        runs = 0;
        wickets = 0;
        if(sFlag == 0)
            sFlag = 1;
        else
            sFlag = 2;
    }
    public void setCurrBat1(int cb1){
        currBat1 = cb1;
    }
    public void setCurrBat2(int cb2){
        currBat2 = cb2;
    }
    public void setCurrBow(int cb){
        currBow = cb;
    }
    public void setCurrKeep(int ck){
        currKeep = ck;
    }
    public void incBall(){
        if(overs - (int)overs < 0.5) {
            overs += 0.1;
        }
        else {
            overs = (int) ++overs;
            swapBat();
        }
    }
    public void incFlag(){
        sFlag++;
    }
    void incBalls(int b){
        for(int i = 0; i < b; i++){
            incBall();
        }
    }
    public void incOvers(double o){
        overs += (int)o;
        incBalls((int)((o - (int)o) * 10));
    }
    public int getRuns(){
        return runs;
    }
    public int getWickets(){
        return wickets;
    }
    public double getOvers(){
        return overs;
    }
    public void incRuns(int r){
        runs += r;
    }
    public void incWickets(){
        wickets++;
    }
    public void swapBat(){
        int p = currBat1;
        currBat1 = currBat2;
        currBat2 = p;
    }
    public int getProjected(){
        int b = (int)(((int)overs * 6) + ((overs - (int)overs) * 10));
        if(b != 0) {
            double rr = runs * 1.0 / b;
            return (int) (runs + rr * (120 - b));
        }
        return 0;
    }
    public MatchState getState(){
        return this;
    }
    public int getFlag(){
        return sFlag;
    }
    public int getBat1(){
        return currBat1;
    }
    public int getBat2(){
        return currBat2;
    }
    public int getBow(){
        return currBow;
    }
    public int getKeep(){
        return currKeep;
    }
}

class MatchResult{
    private int runs;
    private int wickets;
    private double overs;
    public  MatchResult(){
        runs = 0;
        wickets = 0;
        overs = 0.0;
    }
    public MatchResult(int r, int w, double o){
        runs = r;
        wickets = w;
        overs = o;
    }
}
