public class Student {
    private int rollNo;
    private int isa1Marks;
    private int isa2Marks;
    private int quizMarks;
    public Student(int r, int i1, int i2, int q){
        rollNo = r;
        isa1Marks = i1;
        isa2Marks = i2;
        quizMarks = q;
    }
    public boolean checkFailed(){
        return ((isa1Marks+isa2Marks+quizMarks)<20);
    }
    public int getRollNo(){
        return rollNo;
    }
    public int getIsa1Marks(){
        return isa1Marks;
    }
    public int getIsa2Marks(){
        return isa2Marks;
    }
    public int getQuizMarks(){
        return quizMarks;
    }
}
