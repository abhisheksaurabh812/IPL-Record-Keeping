import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class StudentFE {
    private JPanel MainPanel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton clickToAddNewButton;
    private JButton displayAllFailedStudentsButton;
    private JTextArea textArea1;
    private JButton deleteAllFailedStudentsButton;
    private JButton button1;
    private ArrayList<Student> sl;
    public StudentFE() {
        sl = new ArrayList<Student>(5);
        clickToAddNewButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sl.add(new Student(Integer.parseInt(textField1.getText()), Integer.parseInt(textField2.getText()), Integer.parseInt(textField3.getText()), Integer.parseInt(textField4.getText())));
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField4.setText("");
            }
        });
        displayAllFailedStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for(int i=0;i<sl.size();i++)
                    if (sl.get(i).checkFailed())
                        textArea1.append("Roll No. : " + sl.get(i).getRollNo() + "\nISA1 Marks : " + sl.get(i).getIsa2Marks() + "\nISA2 Marks : " + sl.get(i).getIsa2Marks() + "\nQuiz Marks : " + sl.get(i).getQuizMarks() + "\n\n");
            }
        });
        deleteAllFailedStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for(int i=0;i<sl.size();i++)
                    if(sl.get(i).checkFailed())
                        sl.remove(i--);
                textArea1.setText("Failed students deleted\n");
            }
        });
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                for(int i=0;i<sl.size();i++)
                    textArea1.append("Roll No. : " + sl.get(i).getRollNo() + "\nISA1 Marks : " + sl.get(i).getIsa2Marks() + "\nISA2 Marks : " + sl.get(i).getIsa2Marks() + "\nQuiz Marks : " + sl.get(i).getQuizMarks() + "\n\n");
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("StudentFE");
        frame.setContentPane(new StudentFE().MainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
